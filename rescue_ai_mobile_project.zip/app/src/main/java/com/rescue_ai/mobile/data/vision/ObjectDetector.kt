package com.rescue_ai.mobile.data.vision

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.nio.MappedByteBuffer

class ObjectDetector(private val context: Context) {

    private var interpreter: Interpreter? = null
    private var labels: List<String> = emptyList()
    private val modelPath = "ssd_mobilenet_v1.tflite"
    private val labelPath = "labels.txt"

    init {
        try {
            val model: MappedByteBuffer = FileUtil.loadMappedFile(context, modelPath)
            val options = Interpreter.Options().apply {
                setNumThreads(4)
            }
            interpreter = Interpreter(model, options)
            labels = FileUtil.loadLabels(context, labelPath)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun detect(bitmap: Bitmap): List<DetectionResult> {
        if (interpreter == null) return emptyList()

        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(300, 300, ResizeOp.Method.BILINEAR))
            .build()

        var tensorImage = TensorImage.fromBitmap(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val outputLocations = Array(1) { Array(10) { FloatArray(4) } }
        val outputClasses = Array(1) { FloatArray(10) }
        val outputScores = Array(1) { FloatArray(10) }
        val numDetections = FloatArray(1)

        val outputMap = mutableMapOf<Int, Any>(
            0 to outputLocations,
            1 to outputClasses,
            2 to outputScores,
            3 to numDetections
        )

        interpreter?.runForMultipleInputsOutputs(arrayOf(tensorImage.buffer), outputMap)

        val results = mutableListOf<DetectionResult>()
        for (i in 0 until 10) {
            val score = outputScores[0][i]
            if (score > 0.5f) {
                val classIndex = outputClasses[0][i].toInt()
                val label = labels.getOrNull(classIndex) ?: "Unknown"
                val location = outputLocations[0][i]
                results.add(DetectionResult(label, score, location))
            }
        }
        return results
    }

    data class DetectionResult(
        val label: String,
        val confidence: Float,
        val location: FloatArray // [top, left, bottom, right]
    )
}
