package com.rescue_ai.mobile.data.camera

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.rescue_ai.mobile.data.vision.ObjectDetector

class VisionAnalyzer(
    private val detector: ObjectDetector,
    private val onResults: (List<ObjectDetector.DetectionResult>) -> Unit
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        val bitmap = image.toBitmap()
        val rotatedBitmap = rotateBitmap(bitmap, image.imageInfo.rotationDegrees.toFloat())
        
        val results = detector.detect(rotatedBitmap)
        onResults(results)
        
        image.close()
    }

    private fun rotateBitmap(source: Bitmap, angle: Float): Bitmap {
        val matrix = Matrix()
        matrix.postRotate(angle)
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    // Helper to convert ImageProxy to Bitmap
    private fun ImageProxy.toBitmap(): Bitmap {
        val buffer = planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        // Note: Simplified conversion, in production use a more robust YUV to RGB conversion
        return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: 
               Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    }
}
